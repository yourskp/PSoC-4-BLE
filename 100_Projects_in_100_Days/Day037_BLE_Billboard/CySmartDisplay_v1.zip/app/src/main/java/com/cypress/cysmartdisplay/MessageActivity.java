package com.cypress.cysmartdisplay;

import android.app.Activity;
import android.app.ListActivity;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattCallback;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.util.Log;
import android.app.ActionBar;
import android.widget.AdapterView;

import java.util.ArrayList;
import java.util.UUID;
import java.nio.charset.Charset;


public class MessageActivity extends ActionBarActivity {

    private BluetoothAdapter mBluetoothAdapter;
    private BluetoothGatt mBluetoothGatt;
    private boolean mGattConnected;
    private boolean mConnecting;
    private Handler mHandler;
    private String deviceAddress;
    private String deviceName;
    private Menu mOptionsMenu;
    private String MessageEvent;

    public static String MESSAGE_SERVICE = "000018F0-0000-1000-8000-00805F9B34FB";
    public static String MESSAGE_CHAR = "00002AF0-0000-1000-8000-00805F9B34FB";
    public static String SPEED_CHAR = "00002AF1-0000-1000-8000-00805F9B34FB";
    public static String BRIGHTNESS_CHAR = "00002AF2-0000-1000-8000-00805F9B34FB";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        mHandler = new Handler();
        mGattConnected = false;
        mConnecting = false;

        deviceAddress = getIntent().getStringExtra(MainActivity.EXTRAS_DEVICE_ADDRESS);
        deviceName = getIntent().getStringExtra(MainActivity.EXTRAS_DEVICE_NAME);

        TextView textView = (TextView) findViewById(R.id.textView);
        textView.setText(deviceName + "->" + deviceAddress);

        // Initializes a Bluetooth adapter.  For API level 18 and above, get a reference to
        // BluetoothAdapter through BluetoothManager.
        final BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();

        SeekBar brightnessControl = (SeekBar) findViewById(R.id.seekBrightness);
        brightnessControl.setOnSeekBarChangeListener(brightnessSeekTask);

        SeekBar speedControl = (SeekBar) findViewById(R.id.seekSpeed);
        speedControl.setOnSeekBarChangeListener(speedSeekTask);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_message, menu);
        mOptionsMenu = menu;

        mOptionsMenu.findItem(R.id.menu_disconnect).setVisible(false);
        mOptionsMenu.findItem(R.id.menu_connect).setVisible(true);
        mOptionsMenu.findItem(R.id.menu_refresh).setActionView(null);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case R.id.menu_connect:
                Toast.makeText(this, "CONNECT", Toast.LENGTH_SHORT).show();
                connectGatt(true);
                break;
            case R.id.menu_disconnect:
                Toast.makeText(this, "DISCONNECT", Toast.LENGTH_SHORT).show();
                connectGatt(false);
                break;
            default:
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void connectGatt(final boolean enable) {
        if (enable) {
            mGattConnected = false;
            mConnecting = true;
            final BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(deviceAddress);
            mBluetoothGatt = device.connectGatt(getApplicationContext(), false, btleGattCallback);
        } else {
            mBluetoothGatt.disconnect();
            mConnecting = true;
            mGattConnected = false;
        }

        mOptionsMenu.findItem(R.id.menu_connect).setVisible(false);
        mOptionsMenu.findItem(R.id.menu_refresh).setActionView(R.layout.actionbar_progress);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (mGattConnected == true) {
            mBluetoothGatt.disconnect();
            mBluetoothGatt.close();
            mGattConnected = false;
            mBluetoothGatt = null;
        }

        close();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (mGattConnected == true) {
            mBluetoothGatt.disconnect();
            mBluetoothGatt.close();
            mGattConnected = false;
            mBluetoothGatt = null;
        }

        close();
    }

    public void close() {
        if (mBluetoothGatt == null) {
            return;
        }
        mBluetoothGatt.close();
        mBluetoothGatt = null;
    }

    public void sendSmartMessage(View view) {
        findViewById(R.id.btnSend).setVisibility(View.INVISIBLE);
        findViewById(R.id.seekSpeed).setVisibility(View.INVISIBLE);
        findViewById(R.id.seekBrightness).setVisibility(View.INVISIBLE);
        findViewById(R.id.progressBar).setVisibility(View.VISIBLE);
        MessageEvent = "MESSAGE";
        writeMessageCharacteristic(mBluetoothGatt);
    }

    public void clearSmartMessage(View view) {

    }

    private final BluetoothGattCallback btleGattCallback = new BluetoothGattCallback() {

        @Override
        public void onConnectionStateChange(final BluetoothGatt gatt, final int status, final int newState) {
            // this will get called when a device connects or disconnects
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                mBluetoothGatt.discoverServices();
                Log.i("onConnectionStateChange", "CONNECTED");
            }
            else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                mGattConnected = false;
                mConnecting = false;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        findViewById(R.id.btnSend).setVisibility(View.INVISIBLE);
                        findViewById(R.id.seekSpeed).setVisibility(View.INVISIBLE);
                        findViewById(R.id.seekBrightness).setVisibility(View.INVISIBLE);
                        findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
                        mOptionsMenu.findItem(R.id.menu_disconnect).setVisible(false);
                        mOptionsMenu.findItem(R.id.menu_connect).setVisible(true);
                        mOptionsMenu.findItem(R.id.menu_refresh).setActionView(null);
                    }
                });
                Log.i("onConnectionStateChange", "DISCONNECTED");
            }
            else {
                mGattConnected = false;
                Log.i("onConnectionStateChange", "OTHERS");
            }
        }

        @Override
        public void onServicesDiscovered(final BluetoothGatt gatt, final int status) {
            // this will get called after the client initiates a BluetoothGatt.discoverServices() call
            if (status == BluetoothGatt.GATT_SUCCESS) {
                mConnecting = false;
                mGattConnected = true;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        findViewById(R.id.btnSend).setVisibility(View.VISIBLE);
                        findViewById(R.id.seekSpeed).setVisibility(View.VISIBLE);
                        findViewById(R.id.seekBrightness).setVisibility(View.VISIBLE);
                        findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
                        mOptionsMenu.findItem(R.id.menu_disconnect).setVisible(true);
                        mOptionsMenu.findItem(R.id.menu_connect).setVisible(false);
                        mOptionsMenu.findItem(R.id.menu_refresh).setActionView(null);
                    }
                });
                Log.i("onServicesDiscovered", "DISCOVERED");
            }
        }

        @Override
        public void onCharacteristicRead(final BluetoothGatt gatt, final BluetoothGattCharacteristic characteristic,
                                         final int status) {
            // this will get called after the client initiates a BluetoothGatt.discoverServices() call
            if (status == BluetoothGatt.GATT_SUCCESS) {
                // Do nothing now
            }
        }

        @Override
        public void onCharacteristicWrite(final BluetoothGatt gatt, final BluetoothGattCharacteristic characteristic,
                                          final int status){

            if (status == BluetoothGatt.GATT_SUCCESS){
                Log.i("WRITE","Write to Characteristic Success! !");
                mGattConnected = false;
                mConnecting = true;
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        findViewById(R.id.btnSend).setVisibility(View.VISIBLE);
                        findViewById(R.id.seekSpeed).setVisibility(View.VISIBLE);
                        findViewById(R.id.seekBrightness).setVisibility(View.VISIBLE);
                        findViewById(R.id.progressBar).setVisibility(View.INVISIBLE);
                        Toast.makeText(getApplicationContext(), MessageEvent + " SENT", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        }
    };

    public boolean readMessageCharacteristic(final BluetoothGatt gatt){

        boolean status;

        BluetoothGattService Service = gatt.getService(UUID.fromString(MESSAGE_SERVICE));
        if (Service == null) {
            Log.i("writeCharacteristic", "Service not found!");
            return false;
        }
        BluetoothGattCharacteristic characteristic = Service.getCharacteristic(UUID.fromString(MESSAGE_CHAR));
        if (characteristic == null) {
            Log.i("writeCharacteristic", "Char not found!");
            return false;
        }

        status = gatt.readCharacteristic(characteristic);
        return status;
    }

    public boolean writeMessageCharacteristic(final BluetoothGatt gatt){

        boolean status;

        BluetoothGattService Service = gatt.getService(UUID.fromString(MESSAGE_SERVICE));
        if (Service == null) {
            Log.i("writeCharacteristic", "Service not found!");
            return false;
        }
        BluetoothGattCharacteristic characteristic = Service.getCharacteristic(UUID.fromString(MESSAGE_CHAR));
        if (characteristic == null) {
            Log.i("writeCharacteristic", "Char not found!");
            return false;
        }

        String temp = ((EditText) findViewById(R.id.editMessage)).getText().toString();
        byte [] value = temp.getBytes();

        characteristic.setValue(value);
        status = gatt.writeCharacteristic(characteristic);

        return status;
    }

    public boolean writeSpeedCharacteristic(final BluetoothGatt gatt, final int progress){

        boolean status;

        BluetoothGattService Service = gatt.getService(UUID.fromString(MESSAGE_SERVICE));
        if (Service == null) {
            Log.i("writeCharacteristic", "Service not found!");
            return false;
        }
        BluetoothGattCharacteristic characteristic = Service.getCharacteristic(UUID.fromString(SPEED_CHAR));
        if (characteristic == null) {
            Log.i("writeCharacteristic", "Char not found!");
            return false;
        }

        byte [] value = {0};
        value[0] = (byte)progress;
        characteristic.setValue(value);
        status = gatt.writeCharacteristic(characteristic);

        return status;
    }

    public boolean writeBrightnessCharacteristic(final BluetoothGatt gatt, final int progress){

        boolean status;

        BluetoothGattService Service = gatt.getService(UUID.fromString(MESSAGE_SERVICE));
        if (Service == null) {
            Log.i("writeCharacteristic", "Service not found!");
            return false;
        }
        BluetoothGattCharacteristic characteristic = Service.getCharacteristic(UUID.fromString(BRIGHTNESS_CHAR));
        if (characteristic == null) {
            Log.i("writeCharacteristic", "Char not found!");
            return false;
        }

        byte [] value = {0};
        value[0] = (byte) progress;
        characteristic.setValue(value);
        status = gatt.writeCharacteristic(characteristic);

        return status;
    }

    SeekBar.OnSeekBarChangeListener speedSeekTask =
            new SeekBar.OnSeekBarChangeListener() {

                int progressChanged = 0;

                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser){
                    progressChanged = progress;
                }

                public void onStartTrackingTouch(SeekBar seekBar) {
                    // TODO Auto-generated method stub
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                    MessageEvent = "SPEED";
                    writeSpeedCharacteristic(mBluetoothGatt, progressChanged);
                }
            };

    SeekBar.OnSeekBarChangeListener brightnessSeekTask =
            new SeekBar.OnSeekBarChangeListener() {

                int progressChanged = 0;

                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser){
                    progressChanged = progress;
                }

                public void onStartTrackingTouch(SeekBar seekBar) {
                    // TODO Auto-generated method stub
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                    MessageEvent = "BRIGHTNESS";
                    writeBrightnessCharacteristic(mBluetoothGatt, progressChanged);
                }
            };

}
